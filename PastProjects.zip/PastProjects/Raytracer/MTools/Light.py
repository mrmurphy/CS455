# A simple definition of a light


class Light(object):
    def __init__(self, position, color, intensity):
        self.position = position
        self.color = color
        self.intensity = intensity
