This project was written by Murphy Randle in 2012.
Feel free to use for any purpose.
Requires the MTools repository: https://github.com/murphyspublic/MTools
And the canvas library for python: http://taoofmac.com/space/projects/PNGCanvas
