# MTools
These classes are free to use and modify in any way you desire. 
I'd love to hear if you do something cool with them:
`murphyspublic@gmail.com`